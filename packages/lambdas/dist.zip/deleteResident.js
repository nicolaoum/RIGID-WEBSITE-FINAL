"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const handler = async (event) => {
    console.log('Delete Resident Request:', JSON.stringify(event, null, 2));
    try {
        // Get user info from Cognito authorizer
        const claims = event.requestContext?.authorizer?.claims;
        if (!claims) {
            return {
                statusCode: 401,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: 'Unauthorized' }),
            };
        }
        // Check if user is admin
        const groupsClaim = claims['cognito:groups'];
        let groups = [];
        if (typeof groupsClaim === 'string') {
            groups = groupsClaim.split(',').map(g => g.trim());
        }
        else if (Array.isArray(groupsClaim)) {
            groups = groupsClaim;
        }
        const isAdmin = groups.includes('admin');
        if (!isAdmin) {
            return {
                statusCode: 403,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: 'Access denied. Admin role required.' }),
            };
        }
        // Get resident ID from path
        const residentId = event.pathParameters?.id;
        if (!residentId) {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: 'Resident ID is required' }),
            };
        }
        // Delete resident
        await docClient.send(new lib_dynamodb_1.DeleteCommand({
            TableName: process.env.RESIDENTS_TABLE,
            Key: { id: residentId },
        }));
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({ message: 'Resident deleted successfully' }),
        };
    }
    catch (error) {
        console.error('Error deleting resident:', error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({
                message: 'Failed to delete resident',
                error: error instanceof Error ? error.message : 'Unknown error',
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=deleteResident.js.map