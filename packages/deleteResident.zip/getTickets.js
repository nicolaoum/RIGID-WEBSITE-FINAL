"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
/**
 * GET /tickets
 * Returns all tickets for the authenticated resident
 */
const handler = async (event) => {
    console.log('GET /tickets request:', event);
    try {
        // Extract user email from Cognito authorizer context
        const userEmail = event.requestContext.authorizer?.claims?.email || 'unknown@example.com';
        const userId = event.requestContext.authorizer?.claims?.sub || 'unknown';
        // Query tickets by userId (using GSI)
        const result = await docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: process.env.TICKETS_TABLE,
            IndexName: 'userId-index',
            KeyConditionExpression: 'userId = :userId',
            ExpressionAttributeValues: {
                ':userId': userId,
            },
            ScanIndexForward: false, // newest first
        }));
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
            },
            body: JSON.stringify(result.Items || []),
        };
    }
    catch (error) {
        console.error('Error fetching tickets:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true,
            },
            body: JSON.stringify([]),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=getTickets.js.map