import { APIGatewayProxyHandler } from 'aws-lambda';
/**
 * DELETE /units/{id}
 * Deletes a unit (staff/admin only)
 */
export declare const handler: APIGatewayProxyHandler;
