import { APIGatewayProxyHandler } from 'aws-lambda';
/**
 * POST /notices
 * Create a new notice (staff/admin only)
 */
export declare const handler: APIGatewayProxyHandler;
