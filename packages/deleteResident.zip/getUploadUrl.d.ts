import { APIGatewayProxyHandler } from 'aws-lambda';
/**
 * POST /upload-url
 * Generates a presigned URL for uploading images to S3
 */
export declare const handler: APIGatewayProxyHandler;
