"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const client = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const cognitoClient = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({ region: 'us-east-1' });
const handler = async (event) => {
    console.log('Delete Resident Request:', JSON.stringify(event, null, 2));
    try {
        // Get user info from Cognito authorizer
        const claims = event.requestContext?.authorizer?.claims;
        if (!claims) {
            return {
                statusCode: 401,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: 'Unauthorized' }),
            };
        }
        // Check if user is admin
        const groupsClaim = claims['cognito:groups'];
        let groups = [];
        if (typeof groupsClaim === 'string') {
            groups = groupsClaim.split(',').map(g => g.trim());
        }
        else if (Array.isArray(groupsClaim)) {
            groups = groupsClaim;
        }
        const isAdmin = groups.includes('admin');
        if (!isAdmin) {
            return {
                statusCode: 403,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: 'Access denied. Admin role required.' }),
            };
        }
        // Get resident ID from path (can be DynamoDB id or email)
        const residentId = event.pathParameters?.id;
        if (!residentId) {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: 'Resident ID is required' }),
            };
        }
        const userPoolId = process.env.COGNITO_USER_POOL_ID;
        // First, get the resident info from DynamoDB to find their email
        let residentEmail = null;
        let residentDbId = null;
        try {
            const getResult = await docClient.send(new lib_dynamodb_1.GetCommand({
                TableName: process.env.RESIDENTS_TABLE,
                Key: { id: residentId },
            }));
            if (getResult.Item) {
                residentEmail = getResult.Item.email;
                residentDbId = getResult.Item.id;
            }
        }
        catch (error) {
            console.error('Error fetching resident from DynamoDB:', error);
        }
        // If we still don't have an email, try GSI lookup by email (using the path value as email)
        if (!residentEmail && typeof residentId === 'string' && residentId.includes('@')) {
            try {
                const queryResult = await docClient.send(new lib_dynamodb_1.QueryCommand({
                    TableName: process.env.RESIDENTS_TABLE,
                    IndexName: 'email-index',
                    KeyConditionExpression: 'email = :email',
                    ExpressionAttributeValues: {
                        ':email': residentId.toLowerCase(),
                    },
                    Limit: 1,
                }));
                if (queryResult.Items && queryResult.Items.length > 0) {
                    residentEmail = queryResult.Items[0].email;
                    residentDbId = queryResult.Items[0].id;
                }
            }
            catch (queryError) {
                console.error('Error querying resident by email index:', queryError);
            }
        }
        // Fallback: if not found but the path id looks like an email, use it directly
        if (!residentEmail && typeof residentId === 'string' && residentId.includes('@')) {
            residentEmail = residentId.toLowerCase();
        }
        // If we found the email and have a user pool, try to remove from Cognito group
        if (residentEmail && userPoolId) {
            try {
                // Import ListUsers to find user by email
                const { ListUsersCommand } = await Promise.resolve().then(() => __importStar(require('@aws-sdk/client-cognito-identity-provider')));
                // Find the Cognito user with this email
                const listResult = await cognitoClient.send(new ListUsersCommand({
                    UserPoolId: userPoolId,
                    Filter: `email = "${residentEmail}"`,
                    Limit: 1,
                }));
                if (listResult.Users && listResult.Users.length > 0 && listResult.Users[0].Username) {
                    const username = listResult.Users[0].Username;
                    // Remove from resident group
                    await cognitoClient.send(new client_cognito_identity_provider_1.AdminRemoveUserFromGroupCommand({
                        UserPoolId: userPoolId,
                        Username: username,
                        GroupName: 'resident',
                    }));
                    console.log(`Removed ${username} (${residentEmail}) from Cognito resident group`);
                }
                else if (typeof residentId === 'string') {
                    // Fallback: try using the path id directly as the Cognito username
                    await cognitoClient.send(new client_cognito_identity_provider_1.AdminRemoveUserFromGroupCommand({
                        UserPoolId: userPoolId,
                        Username: residentId,
                        GroupName: 'resident',
                    }));
                    console.log(`Fallback: removed ${residentId} from Cognito resident group`);
                }
                else {
                    console.log(`No Cognito user found with email ${residentEmail}`);
                }
            }
            catch (cognitoError) {
                // User might not exist in Cognito or might not be in the group - that's ok
                console.log('Could not remove from Cognito group (user may not exist):', cognitoError.message);
            }
        }
        // Delete resident from DynamoDB (by path id, plus any alternate id we found)
        const deletePromises = [
            docClient.send(new lib_dynamodb_1.DeleteCommand({
                TableName: process.env.RESIDENTS_TABLE,
                Key: { id: residentId },
            })),
        ];
        if (residentDbId && residentDbId !== residentId) {
            deletePromises.push(docClient.send(new lib_dynamodb_1.DeleteCommand({
                TableName: process.env.RESIDENTS_TABLE,
                Key: { id: residentDbId },
            })));
        }
        await Promise.all(deletePromises);
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({ message: 'Resident deleted successfully' }),
        };
    }
    catch (error) {
        console.error('Error deleting resident:', error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({
                message: 'Failed to delete resident',
                error: error instanceof Error ? error.message : 'Unknown error',
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=deleteResident.js.map