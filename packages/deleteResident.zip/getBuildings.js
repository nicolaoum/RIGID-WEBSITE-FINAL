"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
/**
 * GET /buildings
 * Returns all buildings with details and amenities
 */
const handler = async (event) => {
    console.log('GET /buildings request:', event);
    try {
        const result = await docClient.send(new lib_dynamodb_1.ScanCommand({
            TableName: process.env.BUILDINGS_TABLE,
        }));
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
            },
            body: JSON.stringify(result.Items || []),
        };
    }
    catch (error) {
        console.error('Error fetching buildings:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
            },
            body: JSON.stringify({ error: 'Failed to fetch buildings' }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=getBuildings.js.map