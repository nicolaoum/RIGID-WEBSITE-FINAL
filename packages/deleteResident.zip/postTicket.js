"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const crypto_1 = require("crypto");
const client = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
/**
 * POST /tickets
 * Creates a new maintenance ticket (requires authentication)
 */
const handler = async (event) => {
    console.log('POST /tickets request:', JSON.stringify(event, null, 2));
    try {
        // Extract user from Cognito authorizer context
        console.log('Authorizer:', event.requestContext.authorizer);
        const userEmail = event.requestContext.authorizer?.claims?.email || 'unknown@example.com';
        const userId = event.requestContext.authorizer?.claims?.sub || 'unknown';
        console.log('User:', { userId, userEmail });
        const body = JSON.parse(event.body || '{}');
        const { subject, description, priority, residentName, unitNumber, phoneNumber, allowEntry } = body;
        // Validate required fields
        if (!subject || !description || !priority) {
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': 'true',
                },
                body: JSON.stringify({
                    success: false,
                    message: 'Missing required fields: subject, description, priority',
                }),
            };
        }
        // Generate ticket ID
        const ticketId = (0, crypto_1.randomUUID)();
        const now = new Date().toISOString();
        // Create ticket object
        const ticket = {
            id: ticketId,
            userId,
            residentEmail: userEmail,
            subject,
            description,
            priority,
            status: 'open',
            residentName,
            unitNumber,
            phoneNumber,
            allowEntry: allowEntry || false,
            createdAt: now,
            updatedAt: now,
        };
        // Save to DynamoDB
        await docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: process.env.TICKETS_TABLE,
            Item: ticket,
        }));
        console.log('Ticket created:', ticket);
        return {
            statusCode: 201,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true,
            },
            body: JSON.stringify({
                success: true,
                ticketId,
                message: 'Maintenance ticket created successfully',
            }),
        };
    }
    catch (error) {
        console.error('Error creating ticket:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true,
            },
            body: JSON.stringify({
                success: false,
                message: 'Failed to create ticket',
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=postTicket.js.map