import { APIGatewayProxyHandler } from 'aws-lambda';
/**
 * PUT /tickets/{ticketId}/status
 * Updates the status of a ticket (staff/admin only)
 */
export declare const handler: APIGatewayProxyHandler;
