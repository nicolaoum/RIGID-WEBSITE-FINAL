/**
 * POST /residents/register
 * Self-registration endpoint for residents
 * Anyone authenticated can register themselves with email and unit info
 * Status will be 'pending' until admin authorizes them
 */
export declare const handler: (event: any) => Promise<{
    statusCode: number;
    headers: {
        'Access-Control-Allow-Origin': string;
        'Access-Control-Allow-Headers': string;
    };
    body: string;
}>;
