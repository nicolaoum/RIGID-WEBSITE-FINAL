import { APIGatewayProxyHandler } from 'aws-lambda';
/**
 * GET /notices
 * Returns all active notices for residents (requires authentication)
 */
export declare const handler: APIGatewayProxyHandler;
