"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const handler = async (event) => {
    console.log('Delete Ticket Request:', JSON.stringify(event, null, 2));
    try {
        // Get user info from Cognito authorizer
        const claims = event.requestContext?.authorizer?.claims;
        if (!claims) {
            return {
                statusCode: 401,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: 'Unauthorized' }),
            };
        }
        const userEmail = claims.email;
        const userId = claims.sub;
        // Get ticket ID from path (parameter name is 'ticketId')
        const ticketId = event.pathParameters?.ticketId;
        if (!ticketId) {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: 'Ticket ID is required' }),
            };
        }
        const ticketsTable = process.env.TICKETS_TABLE;
        if (!ticketsTable) {
            return {
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: 'Tickets table not configured' }),
            };
        }
        // Query to find the ticket and get its createdAt (sort key)
        const queryResult = await docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: ticketsTable,
            KeyConditionExpression: 'id = :id',
            ExpressionAttributeValues: {
                ':id': ticketId,
            },
            Limit: 1,
        }));
        if (!queryResult.Items || queryResult.Items.length === 0) {
            return {
                statusCode: 404,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: 'Ticket not found' }),
            };
        }
        const ticket = queryResult.Items[0];
        // Check if user is the ticket creator or is staff/admin
        const groupsClaim = claims['cognito:groups'];
        let groups = [];
        if (typeof groupsClaim === 'string') {
            groups = groupsClaim.split(',').map(g => g.trim());
        }
        else if (Array.isArray(groupsClaim)) {
            groups = groupsClaim;
        }
        const isStaff = groups.includes('admin') || groups.includes('staff');
        const isTicketOwner = ticket.residentEmail?.toLowerCase() === userEmail?.toLowerCase() || ticket.userId === userId;
        if (!isStaff && !isTicketOwner) {
            return {
                statusCode: 403,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: 'You do not have permission to delete this ticket' }),
            };
        }
        // Delete the ticket using composite key (id + createdAt)
        await docClient.send(new lib_dynamodb_1.DeleteCommand({
            TableName: ticketsTable,
            Key: {
                id: ticketId,
                createdAt: ticket.createdAt,
            },
        }));
        console.log('Ticket deleted:', ticketId);
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({
                success: true,
                message: 'Ticket deleted successfully',
            }),
        };
    }
    catch (error) {
        console.error('Error deleting ticket:', error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({
                message: 'Failed to delete ticket',
                error: error instanceof Error ? error.message : 'Unknown error',
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=deleteTicket.js.map