"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
/**
 * GET /units
 * Returns all available units with building information
 */
const handler = async (event) => {
    console.log('GET /units request:', event);
    try {
        const result = await docClient.send(new lib_dynamodb_1.ScanCommand({
            TableName: process.env.UNITS_TABLE,
        }));
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
            },
            body: JSON.stringify(result.Items || []),
        };
    }
    catch (error) {
        console.error('Error fetching units:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
            },
            body: JSON.stringify({ error: 'Failed to fetch units' }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=getUnits.js.map