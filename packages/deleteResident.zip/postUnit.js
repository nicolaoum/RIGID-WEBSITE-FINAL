"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const crypto_1 = require("crypto");
const client = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
/**
 * POST /units
 * Creates a new unit (staff/admin only)
 */
const handler = async (event) => {
    console.log('POST /units request:', event);
    try {
        const body = JSON.parse(event.body || '{}');
        const unit = {
            id: `unit-${(0, crypto_1.randomUUID)()}`,
            ...body,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
        };
        await docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: process.env.UNITS_TABLE,
            Item: unit,
        }));
        return {
            statusCode: 201,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
            },
            body: JSON.stringify(unit),
        };
    }
    catch (error) {
        console.error('Error creating unit:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
            },
            body: JSON.stringify({ error: 'Failed to create unit' }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=postUnit.js.map