import { APIGatewayProxyHandler } from 'aws-lambda';
/**
 * GET /buildings
 * Returns all buildings with details and amenities
 */
export declare const handler: APIGatewayProxyHandler;
