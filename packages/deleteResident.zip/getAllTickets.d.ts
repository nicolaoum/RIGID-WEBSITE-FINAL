import { APIGatewayProxyHandler } from 'aws-lambda';
/**
 * GET /tickets/all
 * Returns ALL tickets across all users (staff/admin only)
 */
export declare const handler: APIGatewayProxyHandler;
