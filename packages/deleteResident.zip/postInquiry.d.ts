import { APIGatewayProxyHandler } from 'aws-lambda';
/**
 * POST /inquiries
 * Handles general inquiries from potential residents
 */
export declare const handler: APIGatewayProxyHandler;
