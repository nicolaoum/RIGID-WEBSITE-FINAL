import { APIGatewayProxyHandler } from 'aws-lambda';
/**
 * POST /units
 * Creates a new unit (staff/admin only)
 */
export declare const handler: APIGatewayProxyHandler;
