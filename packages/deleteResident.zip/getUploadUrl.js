"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
const crypto_1 = require("crypto");
const s3Client = new client_s3_1.S3Client({});
/**
 * POST /upload-url
 * Generates a presigned URL for uploading images to S3
 */
const handler = async (event) => {
    console.log('POST /upload-url request:', event);
    try {
        const body = JSON.parse(event.body || '{}');
        const { fileName, contentType } = body;
        if (!fileName || !contentType) {
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': 'true',
                },
                body: JSON.stringify({ error: 'fileName and contentType are required' }),
            };
        }
        const key = `units/${(0, crypto_1.randomUUID)()}-${fileName}`;
        const command = new client_s3_1.PutObjectCommand({
            Bucket: process.env.IMAGES_BUCKET,
            Key: key,
            ContentType: contentType,
        });
        const uploadUrl = await (0, s3_request_presigner_1.getSignedUrl)(s3Client, command, { expiresIn: 3600 });
        const fileUrl = `https://${process.env.IMAGES_BUCKET}.s3.${process.env.AWS_REGION || 'us-east-1'}.amazonaws.com/${key}`;
        console.log('Generated URLs:', { uploadUrl, fileUrl });
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
            },
            body: JSON.stringify({ uploadUrl, fileUrl, key }),
        };
    }
    catch (error) {
        console.error('Error generating upload URL:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
            },
            body: JSON.stringify({ error: 'Failed to generate upload URL' }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=getUploadUrl.js.map