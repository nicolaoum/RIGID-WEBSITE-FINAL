"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
/**
 * DELETE /units/{id}
 * Deletes a unit (staff/admin only)
 */
const handler = async (event) => {
    console.log('DELETE /units/{id} request:', event);
    try {
        const { id } = event.pathParameters || {};
        if (!id) {
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': 'true',
                },
                body: JSON.stringify({ error: 'Unit ID is required' }),
            };
        }
        await docClient.send(new lib_dynamodb_1.DeleteCommand({
            TableName: process.env.UNITS_TABLE,
            Key: { id },
        }));
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
            },
            body: JSON.stringify({ success: true }),
        };
    }
    catch (error) {
        console.error('Error deleting unit:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
            },
            body: JSON.stringify({ error: 'Failed to delete unit' }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=deleteUnit.js.map