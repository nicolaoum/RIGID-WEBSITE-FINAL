import { APIGatewayProxyHandler } from 'aws-lambda';
/**
 * POST /tickets
 * Creates a new maintenance ticket (requires authentication)
 */
export declare const handler: APIGatewayProxyHandler;
