import { APIGatewayProxyHandler } from 'aws-lambda';
/**
 * GET /units
 * Returns all available units with building information
 */
export declare const handler: APIGatewayProxyHandler;
