import { APIGatewayProxyHandler } from 'aws-lambda';
/**
 * GET /tickets
 * Returns all tickets for the authenticated resident
 */
export declare const handler: APIGatewayProxyHandler;
