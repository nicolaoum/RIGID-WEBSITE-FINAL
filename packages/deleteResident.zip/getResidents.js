"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const cognito = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({ region: 'us-east-1' });
const dynamoClient = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
const handler = async (event) => {
    console.log('Get Residents Request:', JSON.stringify(event, null, 2));
    try {
        // Get user info from Cognito authorizer
        const claims = event.requestContext?.authorizer?.claims;
        if (!claims) {
            return {
                statusCode: 401,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: 'Unauthorized' }),
            };
        }
        // Check if user is admin or staff
        const groupsClaim = claims['cognito:groups'];
        let groups = [];
        if (typeof groupsClaim === 'string') {
            groups = groupsClaim.split(',').map(g => g.trim());
        }
        else if (Array.isArray(groupsClaim)) {
            groups = groupsClaim;
        }
        const isAuthorized = groups.includes('admin') || groups.includes('staff');
        if (!isAuthorized) {
            return {
                statusCode: 403,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: 'Access denied. Admin or staff role required.' }),
            };
        }
        const userPoolId = process.env.COGNITO_USER_POOL_ID;
        const residentsTableName = process.env.RESIDENTS_TABLE || 'rigid-residents';
        if (!userPoolId) {
            return {
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: 'User pool not configured' }),
            };
        }
        // STEP 1: Get all residents from DynamoDB (both pending and active)
        let allResidents = [];
        try {
            const dbResult = await docClient.send(new lib_dynamodb_1.ScanCommand({
                TableName: residentsTableName,
            }));
            if (dbResult.Items && dbResult.Items.length > 0) {
                allResidents = dbResult.Items.map((item) => ({
                    id: item.id,
                    email: item.email,
                    name: item.email.split('@')[0], // Default to email prefix if no name
                    unitNumber: item.unitNumber,
                    buildingId: item.buildingId,
                    status: item.status, // 'pending' or 'active'
                    source: 'dynamodb',
                    createdAt: item.createdAt,
                }));
            }
        }
        catch (error) {
            console.error('Error fetching from DynamoDB:', error);
        }
        // STEP 2: Enrich with Cognito data for active residents
        const residentsMap = new Map();
        // First, add all DynamoDB residents to the map
        allResidents.forEach(resident => {
            residentsMap.set(resident.email, resident);
        });
        try {
            // Get all users in the resident group from Cognito
            const residentsResponse = await cognito.send(new client_cognito_identity_provider_1.ListUsersInGroupCommand({
                UserPoolId: userPoolId,
                GroupName: 'resident',
            }));
            // Fetch full user details for each resident
            const cognitoResidents = await Promise.all((residentsResponse.Users || []).map(async (user) => {
                try {
                    const userDetails = await cognito.send(new client_cognito_identity_provider_1.AdminGetUserCommand({
                        UserPoolId: userPoolId,
                        Username: user.Username,
                    }));
                    // Extract attributes
                    const attributes = {};
                    userDetails.UserAttributes?.forEach((attr) => {
                        attributes[attr.Name] = attr.Value;
                    });
                    // Check if this user exists in DynamoDB to get their ID
                    const existingResident = residentsMap.get(attributes.email);
                    return {
                        id: existingResident?.id || attributes.email, // Use DynamoDB ID if available, fallback to email
                        email: attributes.email,
                        name: attributes.name,
                        phoneNumber: attributes.phone_number,
                        unitNumber: attributes['custom:apartmentNumber'],
                        buildingId: attributes['custom:buildingId'],
                        status: 'active',
                        source: 'cognito',
                        createdAt: userDetails.UserCreateDate,
                    };
                }
                catch (error) {
                    console.error(`Error fetching user ${user.Username}:`, error);
                    return null;
                }
            }));
            // Merge Cognito data, overwriting DynamoDB entries for active residents
            cognitoResidents.forEach(resident => {
                if (resident && resident.email) {
                    residentsMap.set(resident.email, resident);
                }
            });
        }
        catch (error) {
            console.error('Error fetching from Cognito:', error);
            // Continue - we still have the DynamoDB residents
        }
        // Convert map to array and filter out nulls
        const validResidents = Array.from(residentsMap.values()).filter((r) => r !== null);
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({
                residents: validResidents,
                count: validResidents.length,
            }),
        };
    }
    catch (error) {
        console.error('Error fetching residents:', error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({
                message: 'Failed to fetch residents',
                error: error instanceof Error ? error.message : 'Unknown error',
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=getResidents.js.map